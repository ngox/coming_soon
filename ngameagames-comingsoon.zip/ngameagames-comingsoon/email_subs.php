<meta http-equiv="refresh" content="0; url=index.php">
<?php
{
  if(isset($_POST["add_email"])){
    $servername = "localhost"; 
    $username = "root";
    $password = "567374";
    $dbname = "ngameagames";
// Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
    if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
    }

    $sql = "INSERT INTO emails (emails)
    VALUES ('".$_POST["email_address"]."')";

  }

  if ($conn->query($sql) === TRUE) {



    echo "<script type= 'text/javascript'>alert('Successful! Stay tuned for updates');</script>";
          //Sending Messages using sender id/short code

  }else {
    echo "<script type= 'text/javascript'>alert('Error: " . $sql . "<br>" . $conn->error."');</script>";
  }

  $conn->close();
}
?>